package com.company.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.company.service.ProductVO;
import com.company.service.SaleVO;

@Repository
public interface ProductMapper {
	public int insertProduct(ProductVO vo);
	public List<ProductVO> getSearchProduct(ProductVO vo);
	public ProductVO getProduct(ProductVO vo);
	public int insertSale(SaleVO vo);
}
