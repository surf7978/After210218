package com.company.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.service.ProductService;
import com.company.service.ProductVO;
import com.company.service.SaleVO;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired ProductMapper dao;
	
	@Override
	public int insertProduct(ProductVO vo) {
		return dao.insertProduct(vo);
	}

	@Override
	public List<ProductVO> getSearchProduct(ProductVO vo) {
		return dao.getSearchProduct(vo);
	}

	@Override
	public ProductVO getProduct(ProductVO vo) {
		return dao.getProduct(vo);
	}

	@Override
	public int insertSale(SaleVO vo) {
		return dao.insertSale(vo);
	}
	
}
