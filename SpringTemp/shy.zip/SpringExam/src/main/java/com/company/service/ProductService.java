package com.company.service;

import java.util.List;

public interface ProductService {
	public int insertProduct(ProductVO vo);
	public List<ProductVO> getSearchProduct(ProductVO vo);
	public ProductVO getProduct(ProductVO vo);
	public int insertSale(SaleVO vo);
}
