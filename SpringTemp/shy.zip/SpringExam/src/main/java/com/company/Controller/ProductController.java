package com.company.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.company.Common.MovieAPI;
import com.company.service.ProductService;
import com.company.service.ProductVO;
import com.company.service.SaleVO;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.google.gson.Gson;

@Controller
public class ProductController {
	Logger logger = LoggerFactory.getLogger(ProductController.class);
	@Autowired ProductService productService;
	@Autowired MovieAPI movieAPI;
	
	//��ü��ȸ
	@RequestMapping("/getSearchProduct")
	public String getSearchUser(ProductVO vo,Model model){
		model.addAttribute("list", productService.getSearchProduct(vo));
		return "/getSearchProduct";
	}
	@GetMapping("/insertProduct")
	public String insertProduct(ProductVO vo,Model model) {
		return "insertProduct";
	}
	
	//���
	@PostMapping("/insertProductt")
	public String insertProductproc(ProductVO vo) {
		logger.debug(vo.toString());
		productService.insertProduct(vo);
		return "redirect:getSearchProduct";
		
	}
	//������ȸ
	@RequestMapping("/directorInfo")
	@ResponseBody
	public List<String> directorInfo() {
		List<String> list = new ArrayList<>();
		Map map = movieAPI.getmovieInfo();
		Map movieInfoResult = (Map)map.get("movieInfoResult");
		Map movieInfo = (Map)movieInfoResult.get("movieInfo");
		List<Map> directors = (List<Map>)movieInfo.get("directors");
		
		for(Map directorList : directors) {
			list.add((String)directorList.get("peopleNm"));
		}
		return list;
	}
	
	//��ǰ��ȸ(json)
	@RequestMapping("/getProduct")
	@ResponseBody 
	public ProductVO getProduct(ProductVO vo) {
		return productService.getProduct(vo);
		
	}
	
	//�������� ���
	@GetMapping("/insertSaleInfo")
	public String insertSaleInfo(SaleVO vo) {
		return "insertSaleInfo";
	}
	
	@RequestMapping("/getSaleInfoo")
	@ResponseBody
	public Map getSaleInfoo(SaleVO vo) {
		int r = productService.insertSale(vo);
		return Collections.singletonMap("cnt",r);
		
	}
		
	
	
}
